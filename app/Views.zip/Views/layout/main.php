<?= $this->include('components/top_layer') ?>
<?= $this->include('components/header_nav') ?>
<?= $this->renderSection('contents') ?>
<?= $this->include('components/footer_info') ?>
<?= $this->include('components/bottom_layer') ?>