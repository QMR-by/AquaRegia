<?= $this->extend('layout/main') ?>

<?= $this->section('contents') ?>

<?= $this->include('components/hero-secs/landing_hero_section') ?> 

<?php echo $message; ?>

<div class="bookflight-container">
    <!-- Book Flight Button -->
    <div class="bookFlight"></div>
    <a href="bookFlight" class="btn btn-primary">Book Flight</a>
</div>

<!-- Flight Search -->
<div class="flightSearch-container">
    <h2>Flight Search</h2>
    <form action="flightSearch" method="get">
        <button type="submit">Search Flights</button>
    </form>
</div>

<!-- Flight Status -->
<div class="flightStatus-container">
    <h2>Flight Status</h2>
    <form action="flightSearch" method="get">
        <input type="text" name="flightNumber" placeholder="Flight Number">
        <button type="submit">Check Status</button>
    </form>
</div>

<!-- Recommended Flights -->
<div class="recommendedFlights-container">
    <h2>Recommended Flights</h2>
    <div id="recommendedCarousel" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <!-- Carousel Items -->
            <div class="carousel-item active">
                <img src="public\img\flight1.jpg" class="d-block w-100" alt="Flight 1">
            </div>
            <div class="carousel-item">
                <img src="public\img\flight2.jpg" class="d-block w-100" alt="Flight 2">
            </div>
            <div class="carousel-item">
                <img src="public\img\flight3.jpg" class="d-block w-100" alt="Flight 3">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#recommendedCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#recommendedCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
</div>

<!-- Site FAQs -->
<div class="faq-container">
        <h2 class="faq-title">FAQs</h2>
        
        <details class="faq-item">
            <summary class="faq-question">Who are we?</summary>
            <p class="faq-answer">
                We are a leading travel agency dedicated to providing the best flight deals and travel experiences to our customers. Our mission is to make travel easy, affordable, and enjoyable for everyone.
            </p>
        </details>
        
        <details class="faq-item">
            <summary class="faq-question">Why choose us?</summary>
            <p class="faq-answer">
                We offer competitive prices, a wide range of flight options, and exceptional customer service. Our team is dedicated to ensuring that your travel experience is seamless and enjoyable from start to finish. We also provide 24/7 support to assist you with any inquiries or issues that may arise during your journey.
            </p>
        </details>
        
        <details class="faq-item">
            <summary class="faq-question">What is the cheapest day of the week to book a flight?</summary>
            <p class="faq-answer">
                According to various studies and travel experts, the cheapest day of the week to book a flight is typically Tuesday. Airlines often release their weekly sales on Monday evenings, and by Tuesday, other airlines have matched these prices, providing travelers with the best deals. However, it's always a good idea to compare prices across different days and times to find the best deal for your specific travel plans.
            </p>
        </details>
        
        <details class="faq-item">
            <summary class="faq-question">How can I save on airline tickets?</summary>
            <p class="faq-answer">
                There are several ways to save on airline tickets:
                <ul class="faq-list">
                    <li><strong>Book in Advance</strong>: Booking your flight tickets well in advance can often result in significant savings.</li>
                    <li><strong>Be Flexible with Dates</strong>: If you have flexibility in your travel dates, you can take advantage of lower fares on less popular travel days.</li>
                    <li><strong>Use Fare Comparison Websites</strong>: Utilize fare comparison websites and apps to compare prices across different airlines and booking platforms.</li>
                    <li><strong>Look for Deals and Promotions</strong>: Keep an eye out for airline sales, promotions, and discount codes.</li>
                    <li><strong>Travel Light</strong>: Avoid extra baggage fees by packing light.</li>
                    <li><strong>Book Connecting Flights</strong>: Sometimes booking connecting flights can be cheaper.</li>
                </ul>
            </p>
        </details>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.11.6/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.3/js/bootstrap.min.js"></script>
<?= $this->endsection('contents') ?>