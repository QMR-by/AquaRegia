<?= $this->extend('layout/main') ?>

<?= $this->section('contents') ?>

<!-- <?= $this->include('components/hero-secs/landing_hero_section') ?> -->
<div class="supportcontainer">
    <div class="support-page">
        <h1>Customer Support</h1>
        <p>If you have any questions or need assistance, please contact our support team.</p>

        <h2>Contact Information</h2>
        <ul>
            <li>Email: tamflightsupport@gmail.com</li>
            <li>Phone: +63 915 170 7594</li>
            <li>Address: 123 Flight St, Travel City, TX 78901</li>
        </ul>
    </div>
</div>


<div class="FAQcontainer">
        <h2>Frequently Asked Questions</h2>
        <div class="accordion" id="faqAccordion">
            <div class="card">
                <div class="card-header" id="headingOne">
                    <h3 class="mb-0">
                        <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            How can I book a flight?
                        </button>
                    </h3>
                </div>
                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        You can book a flight through our website by navigating to the booking section and following the instructions.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingTwo">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            Can I change my booking?
                        </button>
                    </h3>
                </div>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        Yes, you can change your booking by contacting our support team or through the 'Manage Booking' section on our website.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingThree">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            What is your refund policy?
                        </button>
                    </h3>
                </div>
                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        Our refund policy is available on our website. Please refer to the 'Refund Policy' section for detailed information.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingFour">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                            How do I check my flight status?
                        </button>
                    </h3>
                </div>
                <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        You can check your flight status on our website by entering your flight number in the 'Flight Status' section.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingFive">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                            Do you offer travel insurance?
                        </button>
                    </h3>
                </div>
                <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        Yes, we offer travel insurance. You can add it to your booking during the checkout process.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingSix">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                            How do I create an account?
                        </button>
                    </h3>
                </div>
                <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        You can create an account by clicking on the 'Sign Up' button on our homepage and filling out the required information.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingSeven">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                            How do I reset my password?
                        </button>
                    </h3>
                </div>
                <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        You can reset your password by clicking on the 'Forgot Password' link on the login page and following the instructions.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingEight">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                            Can I book a flight for someone else?
                        </button>
                    </h3>
                </div>
                <div id="collapseEight" class="collapse" aria-labelledby="headingEight" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        Yes, you can book a flight for someone else by entering their details in the passenger information section during the booking process.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingNine">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                            How do I cancel my booking?
                        </button>
                    </h3>
                </div>
                <div id="collapseNine" class="collapse" aria-labelledby="headingNine" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        You can cancel your booking by contacting our support team or through the 'Manage Booking' section on our website.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingTen">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                            What documents do I need for my flight?
                        </button>
                    </h3>
                </div>
                <div id="collapseTen" class="collapse" aria-labelledby="headingTen" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        You will need a valid ID and your booking confirmation. For international flights, a passport and visa may be required.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingEleven">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEleven" aria-expanded="false" aria-controls="collapseEleven">
                            Can I bring extra luggage?
                        </button>
                    </h3>
                </div>
                <div id="collapseEleven" class="collapse" aria-labelledby="headingEleven" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        Yes, you can bring extra luggage by purchasing additional baggage allowance during the booking process or at the airport.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingTwelve">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwelve" aria-expanded="false" aria-controls="collapseTwelve">
                            What should I do if my flight is delayed?
                        </button>
                    </h3>
                </div>
                <div id="collapseTwelve" class="collapse" aria-labelledby="headingTwelve" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        If your flight is delayed, please check the flight status on our website or contact our support team for assistance.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingThirteen">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThirteen" aria-expanded="false" aria-controls="collapseThirteen">
                            How do I request special assistance?
                        </button>
                    </h3>
                </div>
                <div id="collapseThirteen" class="collapse" aria-labelledby="headingThirteen" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        You can request special assistance by contacting our support team or selecting the option during the booking process.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingFourteen">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFourteen" aria-expanded="false" aria-controls="collapseFourteen">
                            Can I choose my seat?
                        </button>
                    </h3>
                </div>
                <div id="collapseFourteen" class="collapse" aria-labelledby="headingFourteen" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        Yes, you can choose your seat during the booking process or through the 'Manage Booking' section on our website.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingFifteen">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFifteen" aria-expanded="false" aria-controls="collapseFifteen">
                            What is the check-in process?
                        </button>
                    </h3>
                </div>
                <div id="collapseFifteen" class="collapse" aria-labelledby="headingFifteen" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        You can check in online through our website or at the airport check-in counters. Please arrive at the airport at least 2 hours before your flight.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingSixteen">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSixteen" aria-expanded="false" aria-controls="collapseSixteen">
                            What is your policy on pets?
                        </button>
                    </h3>
                </div>
                <div id="collapseSixteen" class="collapse" aria-labelledby="headingSixteen" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        We allow pets on board. Please refer to our 'Pet Policy' section on the website for detailed information and requirements.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingSeventeen">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeventeen" aria-expanded="false" aria-controls="collapseSeventeen">
                            How do I update my contact information?
                        </button>
                    </h3>
                </div>
                <div id="collapseSeventeen" class="collapse" aria-labelledby="headingSeventeen" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        You can update your contact information through the 'My Account' section on our website.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingEighteen">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEighteen" aria-expanded="false" aria-controls="collapseEighteen">
                            What should I do if I lose my baggage?
                        </button>
                    </h3>
                </div>
                <div id="collapseEighteen" class="collapse" aria-labelledby="headingEighteen" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        If you lose your baggage, please contact our support team immediately for assistance.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingNineteen">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseNineteen" aria-expanded="false" aria-controls="collapseNineteen">
                            What is your policy on unaccompanied minors?
                        </button>
                    </h3>
                </div>
                <div id="collapseNineteen" class="collapse" aria-labelledby="headingNineteen" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        We have a policy for unaccompanied minors. Please refer to our 'Unaccompanied Minors' section on the website for detailed information.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingTwenty">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwenty" aria-expanded="false" aria-controls="collapseTwenty">
                            Can I upgrade my seat?
                        </button>
                    </h3>
                </div>
                <div id="collapseTwenty" class="collapse" aria-labelledby="headingTwenty" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        Yes, you can upgrade your seat during the booking process or through the 'Manage Booking' section on our website.
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingTwentyOne">
                    <h3 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwentyOne" aria-expanded="false" aria-controls="collapseTwentyOne">
                            How do I provide feedback?
                        </button>
                    </h3>
                </div>
                <div id="collapseTwentyOne" class="collapse" aria-labelledby="headingTwentyOne" data-bs-parent="#faqAccordion">
                    <div class="card-body">
                        You can provide feedback by contacting our support team or through the 'Feedback' section on our website.
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.11.6/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.3/js/bootstrap.min.js"></script>
</div>
<?= $this->endSection() ?>