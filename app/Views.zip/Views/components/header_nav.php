<!-- Header -->
<nav class="navbar navbar-expand-sm navbar-dark navbar-custom">
            <div class="container bg-blue">
                <a href="<?= base_url()?>" class="navbar-brand text-uppercase fs-5">
                    <img src="public\img\Logo.png" alt="Logo" width="70" class="d-inline-block align-middle">
                    TamaFlights
                </a>

                <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target=".navbar-collapse">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="list1">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a href="<?= base_url()?>" class="nav-link">Home</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= base_url().'support'?>" class="nav-link">Customer Support Help</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= base_url().'profile'?>" class="btn btn-secondary nav-link">Profile</a>
                        </li>
                    </ul>
                </div>
             </nav>