<!-- Footer -->
<div class="licorice pb-3">
    <div class="container text-center text-md-left mb-5">
        <div class="row card-footer border-white border-opacity-10">
            <div class="mx-auto pt-5 col-md-4 col-lg-4 col-xl-4">
                <h3 class="fw-bold cream">About</h3>
                <p class="fw-bold cream"><a href="#" class="text-decoration-none text-light">Company</a></p>
                <p class="fw-bold cream"><a href="#" class="text-decoration-none text-light">How we work?</a></p>
            </div>

            <div class="mx-auto pt-5 col-8 col-sm-9 col-md-3 col-lg-3 col-xl-3">
                <h3 class="fw-bold cream">Contacts</h3>
                <p><i class="fa fa-envelope me-3" aria-hidden="true"></i> tamaflights@gmail.com</p>
                <p><i class="fa fa-phone me-3" aria-hidden="true"></i> +63 915 170 7592</p>
            </div>

            <div class="mx-auto pt-5 col-8 col-sm-9 col-md-3 col-lg-3 col-xl-3">
                <h3 class="fw-bold cream">Customer Support</h3>
                <p><i class="fa fa-mobile me-3" aria-hidden="true"></i> +63 915 170 7594</p>
                <p><i class="fa fa-envelope me-3" aria-hidden="true"></i> tamflightsupport@gmail.com</p>
                <p><i class="fa fa-facebook me-3" aria-hidden="true"></i> <a href="#" class="text-decoration-none text-light">Facebook</a></p>
                <p><i class="fa fa-instagram me-3" aria-hidden="true"></i> <a href="#" class="text-decoration-none text-light">Instagram</a></p>
            </div>

            <div class="mx-auto pt-5 col-8 col-sm-9 col-md-3 col-lg-3 col-xl-3">
                <h3 class="fw-bold cream">Airlines</h3>
                <a href="<?= base_url('airlines') ?>" class="btn btn-primary">Airlines</a>
            </div>

            <div class="mx-auto pt-5 col-8 col-sm-9 col-md-3 col-lg-3 col-xl-3">
                <h3 class="fw-bold cream">Terms & Services</h3>
                <p class="fw-bold cream"><a href="<?= base_url('terms') ?>" class="text-decoration-none text-light">Terms & Conditions</a></p>
                <p class="fw-bold cream"><a href="<?= base_url('privacy') ?>" class="text-decoration-none text-light">Privacy & Cookies</a></p>
                <p class="fw-bold cream"><a href="<?= base_url('modernSlavery') ?>" class="text-decoration-none text-light">Modern Slavery Statement</a></p>
                <p class="fw-bold cream"><a href="<?= base_url('humanRights') ?>" class="text-decoration-none text-light">Human Rights Statement</a></p>
            </div>
        </div>
    </div>
</div>