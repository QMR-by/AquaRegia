<div class="hero-section">
    <img src="public\img\landing-image.jpg" alt="Landing Hero Image" class="landing-image">
    <h1 class = "fw-bold">TamaFlights</h1>
    <p class = "fw-bold">sub</p>
</div>