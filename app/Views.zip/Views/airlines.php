<?= $this->extend('layout/main') ?>

<?= $this->section('contents') ?>

<div class="airlines-list">
    <div class="airline">
        <img src="public\img\emirates.png" alt="Emirates Logo" width="70" class="d-inline-block align-middle">
        <h3>Emirates</h3>
        <p class="tagline">Fly Better</p>
        <p class="description">Emirates offers exceptional service and a luxurious flying experience worldwide.</p>
    </div>
    <div class="airline">
        <img src="public\img\cebu-pacific.png" alt="Cebu Pacific Logo" width="70" class="d-inline-block align-middle">
        <h3>Cebu Pacific</h3>
        <p class="tagline">Low Fares Made Simple</p>
        <p class="description">Cebu Pacific provides affordable flights with reliable service across numerous destinations.</p>
    </div>
    <div class="airline">
        <img src="public\img\etihad.png" alt="Etihad Logo" width="70" class="d-inline-block align-middle">
        <h3>Etihad</h3>
        <p class="tagline">Beyond the Expected</p>
        <p class="description">Etihad delivers premium travel experiences with a focus on comfort and innovation.</p>
    </div>
    <div class="airline">
        <img src="public\img\philippine-airlines.png" alt="Philippine Airlines Logo" width="70" class="d-inline-block align-middle">
        <h3>Philippine Airlines</h3>
        <p class="tagline">We Go Places Together</p>
        <p class="description">Philippine Airlines connects travelers with exceptional hospitality and extensive route options.</p>
    </div>
    <div class="airline">
        <img src="public\img\air-china.png" alt="Air China Logo" width="70" class="d-inline-block align-middle">
        <h3>Air China</h3>
        <p class="tagline">The World is Your Home</p>
        <p class="description">Air China offers comprehensive flight networks and high-quality service to destinations worldwide.</p>
    </div>
    <div class="airline">
        <img src="public\img\japan-airlines.png" alt="Japan Airlines Logo" width="70" class="d-inline-block align-middle">
        <h3>Japan Airlines</h3>
        <p class="tagline">Going the Extra Mile</p>
        <p class="description">Japan Airlines is renowned for its commitment to customer satisfaction and safety.</p>
    </div>
    <div class="airline">
        <img src="public\img\british-airway.png" alt="British Airways Logo" width="70" class="d-inline-block align-middle">
        <h3>British Airways</h3>
        <p class="tagline">To Fly. To Serve.</p>
        <p class="description">British Airways offers a prestigious flying experience with global connectivity.</p>
    </div>
    <div class="airline">
        <img src="public\img\american-airlines.png" alt="American Airlines Logo" width="70" class="d-inline-block align-middle">
        <h3>American Airlines</h3>
        <p class="tagline">Going for Greatness</p>
        <p class="description">American Airlines provides extensive flight options and dedicated service for travelers.</p>
    </div>
    <div class="airline">
        <img src="public\img\qatar-airways.png" alt="Qatar Airways Logo" width="70" class="d-inline-block align-middle">
        <h3>Qatar Airways</h3>
        <p class="tagline">Going Places Together</p>
        <p class="description">Qatar Airways is committed to excellence, offering superior comfort and service worldwide.</p>
    </div>
</div>

<?= $this->endsection('contents') ?>